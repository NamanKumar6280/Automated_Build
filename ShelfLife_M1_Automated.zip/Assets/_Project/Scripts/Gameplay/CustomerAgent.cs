using UnityEngine;
using UnityEngine.AI;
using ShelfLife.Data;
using ShelfLife.Systems;
using System.Collections;

namespace ShelfLife.Gameplay
{
    [RequireComponent(typeof(NavMeshAgent))]
    public class CustomerAgent : MonoBehaviour
    {
        [SerializeField] private CustomerProfileData profile;
        [SerializeField] private float browseRadius = 5f;
        [SerializeField] private Transform checkoutTarget;

        private NavMeshAgent _agent;
        private CheckoutStateMachine _checkoutMachine;

        public void Initialize(CustomerProfileData data, CheckoutStateMachine checkoutMachine)
        {
            profile = data;
            _checkoutMachine = checkoutMachine;
            _agent = GetComponent<NavMeshAgent>();
            StartCoroutine(CustomerRoutine());
        }

        private IEnumerator CustomerRoutine()
        {
            yield return MoveToRandomPoint();
            float browseTime = Random.Range(profile.minBrowseTime, profile.maxBrowseTime);
            yield return new WaitForSeconds(browseTime);
            int itemCount = Random.Range(profile.minItems, profile.maxItems + 1);
            yield return MoveTo(checkoutTarget.position);
            _checkoutMachine.StartTransaction();
            // In M1 we skip actual product scanning for customers.
            // We'll just complete.
            _checkoutMachine.SubmitPayment(0);
            _checkoutMachine.CompleteTransaction();
            yield return MoveToRandomPoint();
            Destroy(gameObject, 1f);
        }

        private IEnumerator MoveTo(Vector3 pos)
        {
            _agent.SetDestination(pos);
            while (_agent.pathPending || _agent.remainingDistance > 0.5f)
                yield return null;
        }

        private IEnumerator MoveToRandomPoint()
        {
            Vector3 randomPoint = transform.position + Random.insideUnitSphere * browseRadius;
            randomPoint.y = 0;
            yield return MoveTo(randomPoint);
        }
    }
}
