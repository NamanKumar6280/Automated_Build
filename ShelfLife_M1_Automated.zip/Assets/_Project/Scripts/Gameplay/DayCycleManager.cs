using UnityEngine;
using ShelfLife.Systems;
using ShelfLife.Data;
using System;

namespace ShelfLife.Gameplay
{
    public class DayCycleManager : MonoBehaviour
    {
        [SerializeField] private CustomerSpawner spawner;
        [SerializeField] private DaySummaryUI daySummaryUI;
        [SerializeField] private StoreStateData currentState;

        private SaveLoadService _saveService;
        private InventorySystem _inventory = new InventorySystem();
        private int _cash;

        public event Action<int> OnDayStarted;
        public event Action<int, int, int> OnDayEnded;

        private void Awake()
        {
            _saveService = new SaveLoadService(Application.persistentDataPath);
            _cash = 50000;
        }

        private void Start()
        {
            if (_saveService.SaveExists())
            {
                currentState = _saveService.Load();
                _cash = currentState.cashOnHand;
            }
            else
            {
                currentState = new StoreStateData();
                currentState.dayNumber = 1;
                currentState.cashOnHand = 50000;
                _cash = 50000;
            }
        }

        public void StartDay()
        {
            spawner.StartSpawning();
            OnDayStarted?.Invoke(currentState.dayNumber);
        }

        public void EndDay()
        {
            spawner.StopSpawning();
            int revenue = 0; // placeholder
            int costs = 0;
            if (currentState.dayNumber % 7 == 0)
                costs += 1000;
            _cash += revenue - costs;
            currentState.cashOnHand = _cash;
            currentState.dayNumber++;
            _saveService.Save(currentState);
            OnDayEnded?.Invoke(revenue, costs, revenue - costs);
            daySummaryUI.Show(revenue, costs, revenue - costs);
        }

        public void ContinueToNextDay() => StartDay();
    }
}
