using UnityEngine;
using UnityEngine.UI;

namespace ShelfLife.UI
{
    public class HUDController : MonoBehaviour
    {
        [SerializeField] private Text cashText;
        [SerializeField] private Text dayText;
        [SerializeField] private DayCycleManager dayManager;

        private void Update()
        {
            // Placeholder – will be updated with actual data.
        }
    }
}
