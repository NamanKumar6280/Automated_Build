using UnityEngine;

namespace ShelfLife.Data
{
    [CreateAssetMenu(fileName = "Product_", menuName = "Shelf Life/Product Data")]
    public class ProductData : ScriptableObject
    {
        public string displayName;
        public Sprite icon;
        public ProductCategory category;
        public int wholesaleCost;   // in cents
        public int suggestedPrice;  // in cents
        public int shelfStackSize;  // max per slot
    }

    public enum ProductCategory
    {
        PackagedGoods,
        Produce,
    }
}
