using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

namespace ShelfLife.Editor.Setup
{
    public static class SceneGenerator
    {
        public static void GenerateMainMenu()
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/_Project/Scenes/MainMenu.unity") != null)
                return;

            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            // Canvas
            GameObject canvasGO = new GameObject("Canvas");
            Canvas canvas = canvasGO.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvasGO.AddComponent<CanvasScaler>();
            canvasGO.AddComponent<GraphicRaycaster>();

            GameObject panel = new GameObject("Panel");
            panel.transform.SetParent(canvasGO.transform);
            RectTransform rt = panel.AddComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            panel.AddComponent<CanvasRenderer>();
            Image img = panel.AddComponent<Image>();
            img.color = new Color(0.2f, 0.2f, 0.2f, 0.8f);

            // Title
            GameObject title = new GameObject("Title");
            title.transform.SetParent(panel.transform);
            TextMeshProUGUI tmp = title.AddComponent<TextMeshProUGUI>();
            tmp.text = "Shelf Life";
            tmp.fontSize = 60;
            tmp.alignment = TextAlignmentOptions.Center;
            RectTransform trt = title.GetComponent<RectTransform>();
            trt.anchorMin = new Vector2(0.5f, 0.7f);
            trt.anchorMax = new Vector2(0.5f, 0.7f);
            trt.anchoredPosition = Vector2.zero;
            trt.sizeDelta = new Vector2(600, 100);

            // Buttons
            CreateButton(panel, "NewGameButton", "New Game", new Vector2(0.5f, 0.5f), new Vector2(0, 20));
            CreateButton(panel, "ContinueButton", "Continue", new Vector2(0.5f, 0.5f), new Vector2(0, -40));
            CreateButton(panel, "QuitButton", "Quit", new Vector2(0.5f, 0.5f), new Vector2(0, -100));

            GameObject es = new GameObject("EventSystem");
            es.AddComponent<UnityEngine.EventSystems.EventSystem>();
            es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();

            canvasGO.AddComponent<MainMenuUI>();

            if (!AssetDatabase.IsValidFolder("Assets/_Project/Scenes"))
                AssetDatabase.CreateFolder("Assets/_Project", "Scenes");
            EditorSceneManager.SaveScene(scene, "Assets/_Project/Scenes/MainMenu.unity");
            EditorSceneManager.CloseScene(scene, true);
        }

        private static void CreateButton(Transform parent, string name, string label, Vector2 anchorPos, Vector2 offset)
        {
            GameObject btnGO = new GameObject(name);
            btnGO.transform.SetParent(parent);
            RectTransform rt = btnGO.AddComponent<RectTransform>();
            rt.anchorMin = anchorPos;
            rt.anchorMax = anchorPos;
            rt.anchoredPosition = offset;
            rt.sizeDelta = new Vector2(200, 50);
            btnGO.AddComponent<Image>().color = Color.gray;
            Button btn = btnGO.AddComponent<Button>();
            GameObject textGO = new GameObject("Text");
            textGO.transform.SetParent(btnGO.transform);
            TextMeshProUGUI tmp = textGO.AddComponent<TextMeshProUGUI>();
            tmp.text = label;
            tmp.fontSize = 24;
            tmp.alignment = TextAlignmentOptions.Center;
            RectTransform trt = textGO.GetComponent<RectTransform>();
            trt.anchorMin = Vector2.zero;
            trt.anchorMax = Vector2.one;
            trt.offsetMin = Vector2.zero;
            trt.offsetMax = Vector2.zero;
        }

        public static void GenerateShop()
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/_Project/Scenes/Shop.unity") != null)
                return;

            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            // Player
            GameObject player = new GameObject("Player");
            player.AddComponent<CharacterController>();
            player.AddComponent<PlayerController>();
            GameObject cam = new GameObject("Main Camera");
            cam.transform.SetParent(player.transform);
            cam.AddComponent<Camera>();
            cam.AddComponent<AudioListener>();

            // Shelf placeholder
            GameObject shelf = new GameObject("Shelf_Packaged");
            for (int i = 0; i < 6; i++)
            {
                GameObject slot = new GameObject("Slot_" + i);
                slot.transform.SetParent(shelf.transform);
                slot.AddComponent<ShelfSlot>();
                slot.transform.localPosition = new Vector3(i * 0.8f, 0, 0);
            }

            GameObject pallet = new GameObject("DeliveryPallet");
            pallet.AddComponent<DeliveryPallet>();

            GameObject counter = new GameObject("CheckoutCounter");
            counter.AddComponent<BoxCollider>();
            counter.AddComponent<CheckoutCounterInteractor>();

            GameObject spawner = new GameObject("CustomerSpawner");
            spawner.AddComponent<CustomerSpawner>();

            GameObject dayMgr = new GameObject("DayCycleManager");
            dayMgr.AddComponent<DayCycleManager>();

            if (!AssetDatabase.IsValidFolder("Assets/_Project/Scenes"))
                AssetDatabase.CreateFolder("Assets/_Project", "Scenes");
            EditorSceneManager.SaveScene(scene, "Assets/_Project/Scenes/Shop.unity");
            EditorSceneManager.CloseScene(scene, true);
        }
    }
}
