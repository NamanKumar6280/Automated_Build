using UnityEditor;
using UnityEngine;
using System.IO;

namespace ShelfLife.Editor.Build
{
    public static class BuildScript
    {
        public static void BuildAndroid()
        {
            string[] scenes = new string[]
            {
                "Assets/_Project/Scenes/MainMenu.unity",
                "Assets/_Project/Scenes/Shop.unity"
            };

            string buildPath = "Builds/ShelfLife.apk";
            Directory.CreateDirectory("Builds");

            BuildPlayerOptions buildOptions = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = buildPath,
                target = BuildTarget.Android,
                options = BuildOptions.CompressWithLz4HC | BuildOptions.StrictMode
            };

            BuildReport report = BuildPipeline.BuildPlayer(buildOptions);
            if (report.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded)
            {
                Debug.Log("Build succeeded: " + buildPath);
            }
            else
            {
                Debug.LogError("Build failed.");
                throw new System.Exception("Build failed.");
            }
        }
    }
}
