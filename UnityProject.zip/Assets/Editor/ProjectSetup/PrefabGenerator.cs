using UnityEditor;
using UnityEngine;
using ShelfLife.Gameplay;

namespace ShelfLife.Editor.Setup
{
    public static class PrefabGenerator
    {
        private const string PrefabFolder = "Assets/_Project/Prefabs";

        public static void GenerateAllPrefabs()
        {
            if (!AssetDatabase.IsValidFolder(PrefabFolder))
                AssetDatabase.CreateFolder("Assets/_Project", "Prefabs");

            GeneratePrefab("Player.prefab", () =>
            {
                GameObject go = new GameObject("Player");
                go.AddComponent<CharacterController>();
                go.AddComponent<PlayerController>();
                GameObject cam = new GameObject("Main Camera");
                cam.transform.SetParent(go.transform);
                cam.AddComponent<Camera>();
                cam.AddComponent<AudioListener>();
                return go;
            });

            GeneratePrefab("Shelf_Packaged.prefab", () =>
            {
                GameObject go = new GameObject("Shelf_Packaged");
                for (int i = 0; i < 6; i++)
                {
                    GameObject slot = new GameObject("Slot_" + i);
                    slot.transform.SetParent(go.transform);
                    slot.AddComponent<ShelfSlot>();
                    slot.transform.localPosition = new Vector3(i * 0.8f, 0, 0);
                }
                return go;
            });

            GeneratePrefab("ProductBox.prefab", () =>
            {
                GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                go.name = "ProductBox";
                go.AddComponent<StockSource>();
                return go;
            });

            GeneratePrefab("CheckoutCounter.prefab", () =>
            {
                GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                go.name = "CheckoutCounter";
                go.AddComponent<CheckoutCounterInteractor>();
                return go;
            });

            GeneratePrefab("Customer.prefab", () =>
            {
                GameObject go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                go.name = "Customer";
                go.AddComponent<UnityEngine.AI.NavMeshAgent>();
                go.AddComponent<CustomerAgent>();
                return go;
            });

            GeneratePrefab("DeliveryPallet.prefab", () =>
            {
                GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                go.name = "DeliveryPallet";
                go.AddComponent<DeliveryPallet>();
                return go;
            });
        }

        private static void GeneratePrefab(string fileName, System.Func<GameObject> creator)
        {
            string path = PrefabFolder + "/" + fileName;
            if (AssetDatabase.LoadAssetAtPath<GameObject>(path) != null) return;
            GameObject go = creator();
            PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
        }
    }
}
