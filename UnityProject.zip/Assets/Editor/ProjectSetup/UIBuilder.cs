using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using ShelfLife.UI;
using ShelfLife.Gameplay;

namespace ShelfLife.Editor.Setup
{
    public static class UIBuilder
    {
        public static void BuildUIElements()
        {
            EditorSceneManager.OpenScene("Assets/_Project/Scenes/Shop.unity");

            GameObject canvasGO = new GameObject("Canvas");
            Canvas canvas = canvasGO.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvasGO.AddComponent<CanvasScaler>();
            canvasGO.AddComponent<GraphicRaycaster>();

            GameObject hudPanel = new GameObject("HUD");
            hudPanel.transform.SetParent(canvasGO.transform);
            hudPanel.AddComponent<HUDController>();
            CreateText(hudPanel, "CashText", "Cash: $0.00", new Vector2(0.1f, 0.9f), new Vector2(0, 0));
            CreateText(hudPanel, "DayText", "Day 1", new Vector2(0.9f, 0.9f), new Vector2(0, 0));

            GameObject pricingPanel = new GameObject("PricingPanel");
            pricingPanel.transform.SetParent(canvasGO.transform);
            pricingPanel.AddComponent<PricingPanelUI>();

            GameObject checkoutUI = new GameObject("CheckoutUI");
            checkoutUI.transform.SetParent(canvasGO.transform);
            checkoutUI.AddComponent<CheckoutUI>();

            GameObject daySummary = new GameObject("DaySummaryUI");
            daySummary.transform.SetParent(canvasGO.transform);
            daySummary.AddComponent<DaySummaryUI>();

            EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
            EditorSceneManager.CloseScene(EditorSceneManager.GetActiveScene(), true);
        }

        private static void CreateText(Transform parent, string name, string text, Vector2 anchor, Vector2 offset)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent);
            RectTransform rt = go.AddComponent<RectTransform>();
            rt.anchorMin = anchor;
            rt.anchorMax = anchor;
            rt.anchoredPosition = offset;
            TextMeshProUGUI tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.text = text;
            tmp.fontSize = 24;
            tmp.color = Color.white;
        }
    }
}
