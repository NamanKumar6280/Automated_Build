using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using ShelfLife.UI;
using ShelfLife.Gameplay;
using ShelfLife.Data;

namespace ShelfLife.Editor.Setup
{
    public static class ReferenceResolver
    {
        public static void ResolveAll()
        {
            ResolveShop();
        }

        private static void ResolveShop()
        {
            EditorSceneManager.OpenScene("Assets/_Project/Scenes/Shop.unity");

            DayCycleManager dcm = Object.FindObjectOfType<DayCycleManager>();
            CustomerSpawner spawner = Object.FindObjectOfType<CustomerSpawner>();
            DaySummaryUI summary = Object.FindObjectOfType<DaySummaryUI>();

            if (dcm != null && spawner != null && summary != null)
            {
                SerializedObject so = new SerializedObject(dcm);
                so.FindProperty("spawner").objectReferenceValue = spawner;
                so.FindProperty("daySummaryUI").objectReferenceValue = summary;
                so.ApplyModifiedProperties();
            }

            if (spawner != null)
            {
                SerializedObject so = new SerializedObject(spawner);
                so.FindProperty("customerPrefab").objectReferenceValue = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Project/Prefabs/Customer.prefab");
                GameObject spawnPointGO = GameObject.Find("SpawnPoint");
                if (spawnPointGO == null)
                {
                    spawnPointGO = new GameObject("SpawnPoint");
                    spawnPointGO.transform.position = new Vector3(10, 0, 0);
                }
                so.FindProperty("spawnPoint").objectReferenceValue = spawnPointGO.transform;
                so.FindProperty("defaultProfile").objectReferenceValue = AssetDatabase.LoadAssetAtPath<CustomerProfileData>("Assets/_Project/Data/CustomerProfiles/DefaultCustomer.asset");
                so.ApplyModifiedProperties();
            }

            DeliveryPallet pallet = Object.FindObjectOfType<DeliveryPallet>();
            if (pallet != null)
            {
                SerializedObject so = new SerializedObject(pallet);
                so.FindProperty("productBoxPrefab").objectReferenceValue = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_Project/Prefabs/ProductBox.prefab");
                GameObject spawnPointGO = GameObject.Find("PalletSpawnPoint");
                if (spawnPointGO == null)
                {
                    spawnPointGO = new GameObject("PalletSpawnPoint");
                    spawnPointGO.transform.position = new Vector3(-2, 0, 0);
                }
                so.FindProperty("spawnPoint").objectReferenceValue = spawnPointGO.transform;
                so.ApplyModifiedProperties();
            }

            PricingPanelUI pricing = Object.FindObjectOfType<PricingPanelUI>();
            if (pricing != null)
            {
                SerializedObject so = new SerializedObject(pricing);
                string[] guids = AssetDatabase.FindAssets("t:ProductData");
                ProductData[] products = new ProductData[guids.Length];
                for (int i = 0; i < guids.Length; i++)
                {
                    string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                    products[i] = AssetDatabase.LoadAssetAtPath<ProductData>(path);
                }
                so.FindProperty("products").arraySize = products.Length;
                for (int i = 0; i < products.Length; i++)
                    so.FindProperty("products").GetArrayElementAtIndex(i).objectReferenceValue = products[i];
                so.ApplyModifiedProperties();
            }

            EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
            EditorSceneManager.CloseScene(EditorSceneManager.GetActiveScene(), true);
        }
    }
}
