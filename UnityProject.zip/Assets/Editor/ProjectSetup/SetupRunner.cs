using UnityEditor;
using UnityEngine;

namespace ShelfLife.Editor.Setup
{
    public static class SetupRunner
    {
        [MenuItem("Tools/Project/Complete Setup")]
        public static void Run()
        {
            Debug.Log("=== Shelf Life Project Setup Started ===");
            ScriptableObjectGenerator.GenerateAll();
            InputAssetGenerator.Generate();
            SceneGenerator.GenerateMainMenu();
            SceneGenerator.GenerateShop();
            PrefabGenerator.GenerateAllPrefabs();
            UIBuilder.BuildUIElements();
            ReferenceResolver.ResolveAll();
            BuildConfigurator.Configure();
            NavMeshBaker.BakeShopNavMesh();
            LightmapBaker.BakeShopLighting();
            Validator.Validate();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("=== Project Setup Complete ===");
        }
    }
}
