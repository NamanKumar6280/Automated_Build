using UnityEditor;
using UnityEngine;
using ShelfLife.Data;

namespace ShelfLife.Editor.Setup
{
    public static class ScriptableObjectGenerator
    {
        private const string ProductFolder = "Assets/_Project/Data/Products";
        private const string ProfileFolder = "Assets/_Project/Data/CustomerProfiles";

        public static void GenerateAll()
        {
            EnsureFolder(ProductFolder);
            EnsureFolder(ProfileFolder);

            ProductData beans = ScriptableObject.CreateInstance<ProductData>();
            beans.displayName = "Canned Beans";
            beans.category = ProductCategory.PackagedGoods;
            beans.wholesaleCost = 100;
            beans.suggestedPrice = 130;
            beans.shelfStackSize = 10;
            AssetDatabase.CreateAsset(beans, ProductFolder + "/CannedBeans.asset");

            ProductData soup = ScriptableObject.CreateInstance<ProductData>();
            soup.displayName = "Tomato Soup";
            soup.category = ProductCategory.PackagedGoods;
            soup.wholesaleCost = 80;
            soup.suggestedPrice = 110;
            soup.shelfStackSize = 12;
            AssetDatabase.CreateAsset(soup, ProductFolder + "/TomatoSoup.asset");

            CustomerProfileData defaultProfile = ScriptableObject.CreateInstance<CustomerProfileData>();
            defaultProfile.patience = 30f;
            defaultProfile.budgetSensitivity = 0.5f;
            defaultProfile.listAdherence = 0.7f;
            defaultProfile.minBrowseTime = 5f;
            defaultProfile.maxBrowseTime = 15f;
            defaultProfile.minItems = 1;
            defaultProfile.maxItems = 4;
            AssetDatabase.CreateAsset(defaultProfile, ProfileFolder + "/DefaultCustomer.asset");
        }

        private static void EnsureFolder(string path)
        {
            if (!AssetDatabase.IsValidFolder(path))
            {
                string parent = System.IO.Path.GetDirectoryName(path);
                string folder = System.IO.Path.GetFileName(path);
                AssetDatabase.CreateFolder(parent, folder);
            }
        }
    }
}
