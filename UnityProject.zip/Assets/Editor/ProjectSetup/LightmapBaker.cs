using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace ShelfLife.Editor.Setup
{
    public static class LightmapBaker
    {
        public static void BakeShopLighting()
        {
            EditorSceneManager.OpenScene("Assets/_Project/Scenes/Shop.unity");

            Light light = Object.FindObjectOfType<Light>();
            if (light == null)
            {
                GameObject lightGO = new GameObject("Directional Light");
                light = lightGO.AddComponent<Light>();
                light.type = LightType.Directional;
                lightGO.transform.rotation = Quaternion.Euler(50, -30, 0);
            }
            Lightmapping.Bake();

            EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
            EditorSceneManager.CloseScene(EditorSceneManager.GetActiveScene(), true);
        }
    }
}
