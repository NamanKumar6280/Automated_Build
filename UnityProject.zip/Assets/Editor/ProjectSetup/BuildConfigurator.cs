using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor.Rendering.Universal;

namespace ShelfLife.Editor.Setup
{
    public static class BuildConfigurator
    {
        public static void Configure()
        {
            PlayerSettings.productName = "Shelf Life";
            PlayerSettings.companyName = "YourCompany";
            PlayerSettings.bundleVersion = "0.1.0";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.yourcompany.shelflife");
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevel30;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetArchitecture(BuildTargetGroup.Android, 1);

            CreateURPAsset();

            EditorBuildSettings.scenes = new EditorBuildSettingsScene[]
            {
                new EditorBuildSettingsScene("Assets/_Project/Scenes/MainMenu.unity", true),
                new EditorBuildSettingsScene("Assets/_Project/Scenes/Shop.unity", true)
            };

            QualitySettings.SetQualityLevel(0, true);
        }

        private static void CreateURPAsset()
        {
            string pipelinePath = "Assets/_Project/Settings/UniversalRenderPipelineAsset.asset";
            if (AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(pipelinePath) != null)
                return;

            if (!AssetDatabase.IsValidFolder("Assets/_Project/Settings"))
                AssetDatabase.CreateFolder("Assets/_Project", "Settings");

            var urpAsset = UniversalRenderPipelineAsset.Create();
            urpAsset.shadowDistance = 50;
            urpAsset.mainLightShadowsEnabled = true;
            urpAsset.msaaSampleCount = 4;
            urpAsset.renderScale = 1f;
            AssetDatabase.CreateAsset(urpAsset, pipelinePath);

            GraphicsSettings.defaultRenderPipeline = urpAsset;
            GraphicsSettings.renderPipelineAsset = urpAsset;
            QualitySettings.renderPipeline = urpAsset;
        }
    }
}
