using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using Unity.AI.Navigation;

namespace ShelfLife.Editor.Setup
{
    public static class NavMeshBaker
    {
        public static void BakeShopNavMesh()
        {
            EditorSceneManager.OpenScene("Assets/_Project/Scenes/Shop.unity");

            NavMeshSurface surface = Object.FindObjectOfType<NavMeshSurface>();
            if (surface == null)
            {
                GameObject go = new GameObject("NavMeshSurface");
                surface = go.AddComponent<NavMeshSurface>();
                surface.collectObjects = CollectObjects.Children;
            }
            surface.BuildNavMesh();

            EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
            EditorSceneManager.CloseScene(EditorSceneManager.GetActiveScene(), true);
        }
    }
}
