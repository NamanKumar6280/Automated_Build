using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using System.IO;

namespace ShelfLife.Editor.Setup
{
    public static class InputAssetGenerator
    {
        public static void Generate()
        {
            string path = "Assets/_Project/Input/PlayerControls.inputactions";
            if (AssetDatabase.LoadAssetAtPath<InputActionAsset>(path) != null) return;

            if (!AssetDatabase.IsValidFolder("Assets/_Project/Input"))
                AssetDatabase.CreateFolder("Assets/_Project", "Input");

            string json = @"
{
    ""name"": ""PlayerControls"",
    ""maps"": [
        {
            ""name"": ""Player"",
            ""id"": ""12345678-1234-1234-1234-123456789012"",
            ""actions"": [
                { ""name"": ""Move"", ""type"": ""Value"", ""expectedControlType"": ""Vector2"", ""id"": ""12345678-1234-1234-1234-123456789013"" },
                { ""name"": ""Look"", ""type"": ""Value"", ""expectedControlType"": ""Vector2"", ""id"": ""12345678-1234-1234-1234-123456789014"" },
                { ""name"": ""Interact"", ""type"": ""Button"", ""expectedControlType"": ""Button"", ""id"": ""12345678-1234-1234-1234-123456789015"" }
            ],
            ""bindings"": [
                { ""path"": ""<Gamepad>/leftStick"", ""action"": ""Move"", ""groups"": ""Gamepad"" },
                { ""path"": ""<Keyboard>/w"", ""action"": ""Move"", ""groups"": ""Keyboard"", ""modifiers"": ""Vector2(0,1)"" },
                { ""path"": ""<Keyboard>/s"", ""action"": ""Move"", ""groups"": ""Keyboard"", ""modifiers"": ""Vector2(0,-1)"" },
                { ""path"": ""<Keyboard>/a"", ""action"": ""Move"", ""groups"": ""Keyboard"", ""modifiers"": ""Vector2(-1,0)"" },
                { ""path"": ""<Keyboard>/d"", ""action"": ""Move"", ""groups"": ""Keyboard"", ""modifiers"": ""Vector2(1,0)"" },
                { ""path"": ""<Gamepad>/rightStick"", ""action"": ""Look"", ""groups"": ""Gamepad"" },
                { ""path"": ""<Mouse>/delta"", ""action"": ""Look"", ""groups"": ""Keyboard&Mouse"" },
                { ""path"": ""<Mouse>/leftButton"", ""action"": ""Interact"", ""groups"": ""Keyboard&Mouse"" },
                { ""path"": ""<Keyboard>/e"", ""action"": ""Interact"", ""groups"": ""Keyboard"" }
            ]
        }
    ],
    ""controlSchemes"": [
        { ""name"": ""Keyboard&Mouse"", ""bindingGroup"": ""Keyboard&Mouse"" },
        { ""name"": ""Gamepad"", ""bindingGroup"": ""Gamepad"" }
    ]
}";
            File.WriteAllText(path, json);
            AssetDatabase.Refresh();
        }
    }
}
