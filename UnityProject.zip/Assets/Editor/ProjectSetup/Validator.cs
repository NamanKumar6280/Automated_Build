using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.InputSystem;
using System.Collections.Generic;
using System.Linq;

namespace ShelfLife.Editor.Setup
{
    public static class Validator
    {
        public static void Validate()
        {
            Debug.Log("=== Validation Started ===");
            bool error = false;

            if (AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/_Project/Scenes/MainMenu.unity") == null)
            { Debug.LogError("MainMenu scene missing."); error = true; }
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/_Project/Scenes/Shop.unity") == null)
            { Debug.LogError("Shop scene missing."); error = true; }

            string[] prefabNames = { "Player", "Shelf_Packaged", "ProductBox", "CheckoutCounter", "Customer", "DeliveryPallet" };
            foreach (var name in prefabNames)
            {
                string path = $"Assets/_Project/Prefabs/{name}.prefab";
                if (AssetDatabase.LoadAssetAtPath<GameObject>(path) == null)
                { Debug.LogError($"Prefab {name} missing."); error = true; }
            }

            if (AssetDatabase.FindAssets("t:ProductData").Length == 0)
            { Debug.LogError("No ProductData assets."); error = true; }
            if (AssetDatabase.FindAssets("t:CustomerProfileData").Length == 0)
            { Debug.LogError("No CustomerProfileData assets."); error = true; }

            if (GraphicsSettings.defaultRenderPipeline == null)
            { Debug.LogError("URP pipeline not assigned."); error = true; }

            var scenes = EditorBuildSettings.scenes;
            if (scenes.Length != 2 || !scenes[0].enabled || !scenes[1].enabled)
            { Debug.LogError("Build settings scenes missing."); error = true; }

            if (AssetDatabase.LoadAssetAtPath<InputActionAsset>("Assets/_Project/Input/PlayerControls.inputactions") == null)
            { Debug.LogError("Input Action Asset missing."); error = true; }

            if (error)
            {
                Debug.LogError("Validation FAILED.");
                throw new System.Exception("Project validation failed.");
            }
            else
                Debug.Log("Validation PASSED.");
        }
    }
}
