using UnityEngine;
using ShelfLife.Data;

namespace ShelfLife.Gameplay
{
    public class ShelfSlot : MonoBehaviour
    {
        [SerializeField] private ProductData currentProduct;
        [SerializeField] private int currentCount = 0;
        [SerializeField] private int maxStack = 10;

        public ProductData Product => currentProduct;
        public int Count => currentCount;
        public bool IsFull => currentProduct != null && currentCount >= (currentProduct?.shelfStackSize ?? maxStack);

        public bool TryPlace(ProductData product, int amount)
        {
            if (amount <= 0) return false;
            if (currentProduct != null && currentProduct != product) return false;
            if (currentProduct == null)
            {
                currentProduct = product;
                currentCount = 0;
            }
            int max = product.shelfStackSize;
            int space = max - currentCount;
            int add = Mathf.Min(amount, space);
            currentCount += add;
            return add > 0;
        }

        public bool TryTake(out ProductData product, int amount)
        {
            product = null;
            if (currentProduct == null || currentCount <= 0) return false;
            int take = Mathf.Min(amount, currentCount);
            product = currentProduct;
            currentCount -= take;
            if (currentCount == 0) currentProduct = null;
            return take > 0;
        }

        public void Clear()
        {
            currentProduct = null;
            currentCount = 0;
        }
    }
}
