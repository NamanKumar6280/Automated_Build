using UnityEngine;
using ShelfLife.Systems;
using ShelfLife.Data;

namespace ShelfLife.Gameplay
{
    public class CheckoutCounterInteractor : MonoBehaviour
    {
        private CheckoutStateMachine _stateMachine = new CheckoutStateMachine();
        private InventorySystem _inventory = new InventorySystem();

        public void StartCheckout() => _stateMachine.StartTransaction();

        public void ScanItem(ProductData product)
        {
            if (_stateMachine.CurrentState != CheckoutStateMachine.State.Scanning) return;
            if (_inventory.RemoveStock(product, 1))
                _stateMachine.ScanProduct(product, GetPrice(product));
        }

        private int GetPrice(ProductData product) => product.suggestedPrice;

        public void SubmitPayment(int amount) => _stateMachine.SubmitPayment(amount);

        public void CompleteTransaction()
        {
            if (_stateMachine.CurrentState != CheckoutStateMachine.State.Payment) return;
            _stateMachine.CompleteTransaction();
        }
    }
}
