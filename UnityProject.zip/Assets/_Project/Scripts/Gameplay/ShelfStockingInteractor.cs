using UnityEngine;
using ShelfLife.Data;
using ShelfLife.Systems;

namespace ShelfLife.Gameplay
{
    public class ShelfStockingInteractor : MonoBehaviour
    {
        [SerializeField] private float interactRange = 2f;
        [SerializeField] private LayerMask shelfLayer;

        private InventorySystem _inventory = new InventorySystem();
        private ProductData _heldProduct;
        private int _heldAmount;

        private void Update()
        {
            if (Input.GetButtonDown("Interact"))
                TryInteract();
        }

        private void TryInteract()
        {
            Ray ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width/2, Screen.height/2));
            if (Physics.Raycast(ray, out RaycastHit hit, interactRange, shelfLayer))
            {
                ShelfSlot slot = hit.collider.GetComponent<ShelfSlot>();
                if (slot != null && _heldProduct != null && _heldAmount > 0)
                {
                    int space = slot.Product?.shelfStackSize ?? 10;
                    if (slot.Product != null && slot.Product == _heldProduct)
                        space -= slot.Count;
                    else if (slot.Product == null)
                        space = _heldProduct.shelfStackSize;
                    int placeAmount = Mathf.Min(_heldAmount, space);
                    if (placeAmount > 0)
                    {
                        slot.TryPlace(_heldProduct, placeAmount);
                        _heldAmount -= placeAmount;
                        if (_heldAmount == 0) _heldProduct = null;
                    }
                }
            }
        }

        public void PickUpBox(ProductData product, int amount)
        {
            _heldProduct = product;
            _heldAmount = amount;
        }
    }
}
