using UnityEngine;
using UnityEngine.InputSystem;

namespace ShelfLife.Gameplay
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        [SerializeField] private float walkSpeed = 3f;
        [SerializeField] private float lookSensitivity = 1f;
        private CharacterController _controller;
        private Vector2 _moveInput;
        private Vector2 _lookInput;
        private float _yaw;
        private float _pitch;

        private void Awake()
        {
            _controller = GetComponent<CharacterController>();
            Cursor.lockState = CursorLockMode.Locked;
        }

        public void OnMove(InputAction.CallbackContext context)
        {
            _moveInput = context.ReadValue<Vector2>();
        }

        public void OnLook(InputAction.CallbackContext context)
        {
            _lookInput = context.ReadValue<Vector2>();
        }

        private void Update()
        {
            _yaw += _lookInput.x * lookSensitivity * Time.deltaTime;
            _pitch -= _lookInput.y * lookSensitivity * Time.deltaTime;
            _pitch = Mathf.Clamp(_pitch, -80f, 80f);
            transform.eulerAngles = new Vector3(_pitch, _yaw, 0f);

            Vector3 forward = transform.forward;
            Vector3 right = transform.right;
            forward.y = 0f;
            right.y = 0f;
            forward.Normalize();
            right.Normalize();

            Vector3 move = (forward * _moveInput.y + right * _moveInput.x) * walkSpeed;
            move.y = -9.81f;
            _controller.Move(move * Time.deltaTime);
        }
    }
}
