using UnityEngine;
using ShelfLife.Systems;
using ShelfLife.Data;

namespace ShelfLife.Gameplay
{
    public class CustomerSpawner : MonoBehaviour
    {
        [SerializeField] private GameObject customerPrefab;
        [SerializeField] private Transform spawnPoint;
        [SerializeField] private CustomerProfileData defaultProfile;
        [SerializeField] private float spawnInterval = 10f;
        [SerializeField] private int maxConcurrent = 4;

        private CheckoutStateMachine _checkoutMachine = new CheckoutStateMachine();
        private int _activeCount = 0;
        private float _timer = 0f;
        private bool _isOpen = false;

        public void StartSpawning() { _isOpen = true; _timer = 0f; }
        public void StopSpawning() { _isOpen = false; }

        private void Update()
        {
            if (!_isOpen) return;
            _timer += Time.deltaTime;
            if (_timer >= spawnInterval && _activeCount < maxConcurrent)
            {
                SpawnCustomer();
                _timer = 0f;
            }
        }

        private void SpawnCustomer()
        {
            GameObject go = Instantiate(customerPrefab, spawnPoint.position, Quaternion.identity);
            CustomerAgent agent = go.GetComponent<CustomerAgent>();
            if (agent != null)
            {
                agent.Initialize(defaultProfile, _checkoutMachine);
                _activeCount++;
            }
        }

        public void OnCustomerDestroyed() => _activeCount--;
    }
}
