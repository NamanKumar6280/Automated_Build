using UnityEngine;
using ShelfLife.Data;
using ShelfLife.Systems;

namespace ShelfLife.Gameplay
{
    public class DeliveryPallet : MonoBehaviour
    {
        [SerializeField] private GameObject productBoxPrefab;
        [SerializeField] private Transform spawnPoint;

        private InventorySystem _inventory = new InventorySystem();

        public void SpawnDailyStock(ProductData[] products, int[] quantities)
        {
            for (int i = 0; i < products.Length; i++)
            {
                if (quantities[i] <= 0) continue;
                GameObject box = Instantiate(productBoxPrefab, spawnPoint.position, spawnPoint.rotation);
                var stockSource = box.GetComponent<StockSource>();
                if (stockSource != null)
                    stockSource.SetProduct(products[i], quantities[i]);
            }
        }
    }

    public class StockSource : MonoBehaviour
    {
        public ProductData product;
        public int amount;
        public void SetProduct(ProductData p, int a) { product = p; amount = a; }
    }
}
