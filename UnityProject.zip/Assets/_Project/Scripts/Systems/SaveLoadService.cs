using System;
using System.IO;
using UnityEngine;
using ShelfLife.Data;

namespace ShelfLife.Systems
{
    public class SaveLoadService
    {
        private readonly string _savePath;

        public SaveLoadService(string persistentDataPath)
        {
            _savePath = Path.Combine(persistentDataPath, "save.json");
        }

        public bool SaveExists() => File.Exists(_savePath);

        public void Save(StoreStateData data)
        {
            data.schemaVersion = 1;
            string json = JsonUtility.ToJson(data, true);
            File.WriteAllText(_savePath, json);
        }

        public StoreStateData Load()
        {
            if (!SaveExists()) return null;
            string json = File.ReadAllText(_savePath);
            StoreStateData data = JsonUtility.FromJson<StoreStateData>(json);
            if (data == null) return null;
            if (data.schemaVersion != 1)
                throw new NotSupportedException($"Schema version {data.schemaVersion} not supported.");
            return data;
        }

        public void DeleteSave()
        {
            if (SaveExists()) File.Delete(_savePath);
        }
    }
}
