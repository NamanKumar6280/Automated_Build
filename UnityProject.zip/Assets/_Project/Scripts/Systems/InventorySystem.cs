using System.Collections.Generic;
using ShelfLife.Data;

namespace ShelfLife.Systems
{
    public class InventorySystem
    {
        private Dictionary<ProductData, int> _stock = new Dictionary<ProductData, int>();

        public void AddStock(ProductData product, int amount)
        {
            if (amount <= 0) return;
            if (_stock.ContainsKey(product))
                _stock[product] += amount;
            else
                _stock[product] = amount;
        }

        public bool RemoveStock(ProductData product, int amount)
        {
            if (amount <= 0) return false;
            if (!_stock.TryGetValue(product, out int current)) return false;
            if (current < amount) return false;
            _stock[product] = current - amount;
            if (_stock[product] == 0)
                _stock.Remove(product);
            return true;
        }

        public int GetStock(ProductData product)
        {
            return _stock.TryGetValue(product, out int val) ? val : 0;
        }

        public IEnumerable<KeyValuePair<ProductData, int>> GetAllStock() => _stock;

        public Dictionary<string, int> ToSerializable()
        {
            var dict = new Dictionary<string, int>();
            foreach (var kvp in _stock)
                dict[kvp.Key.name] = kvp.Value;
            return dict;
        }

        public void FromSerializable(Dictionary<string, int> data, System.Func<string, ProductData> resolver)
        {
            _stock.Clear();
            foreach (var kvp in data)
            {
                var product = resolver(kvp.Key);
                if (product != null)
                    _stock[product] = kvp.Value;
            }
        }
    }
}
