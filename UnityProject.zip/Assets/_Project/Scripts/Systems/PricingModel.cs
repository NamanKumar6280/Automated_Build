using ShelfLife.Data;
using UnityEngine;

namespace ShelfLife.Systems
{
    public static class PricingModel
    {
        public static int ComputeSuggestedPrice(ProductData product, float demandMultiplier = 1.0f)
        {
            float margin = 0.30f * demandMultiplier;
            int price = (int)(product.wholesaleCost * (1f + margin));
            price = (price + 2) / 5 * 5;
            return price;
        }

        public static float ProjectedSellThrough(ProductData product, int currentPrice, int stockLevel)
        {
            float baseDemand = 0.8f;
            float priceRatio = (float)currentPrice / product.suggestedPrice;
            float elasticity = 1.2f;
            float demand = baseDemand * Mathf.Pow(priceRatio, -elasticity);
            return Mathf.Min(demand, stockLevel);
        }
    }
}
