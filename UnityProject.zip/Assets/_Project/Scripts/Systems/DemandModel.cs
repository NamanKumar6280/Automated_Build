using UnityEngine;

namespace ShelfLife.Systems
{
    public class DemandModel
    {
        private float _currentFluctuation = 1.0f;

        public DemandModel(int seed)
        {
            Random.InitState(seed);
        }

        public float GetWholesalePriceMultiplier()
        {
            float step = Random.Range(-0.03f, 0.03f);
            _currentFluctuation += step;
            _currentFluctuation = Mathf.Clamp(_currentFluctuation, 0.8f, 1.2f);
            return _currentFluctuation;
        }

        public void ResetTo(float value) => _currentFluctuation = value;
    }
}
