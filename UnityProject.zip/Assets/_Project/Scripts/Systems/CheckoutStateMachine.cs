using System;
using System.Collections.Generic;
using ShelfLife.Data;

namespace ShelfLife.Systems
{
    public class CheckoutStateMachine
    {
        public enum State { Idle, Scanning, Payment, Complete }

        private State _state = State.Idle;
        private List<ProductData> _scannedItems = new List<ProductData>();
        private int _totalCents = 0;
        private int _amountPaid = 0;
        private int _changeDue = 0;

        public State CurrentState => _state;
        public IReadOnlyList<ProductData> ScannedItems => _scannedItems;
        public int TotalCents => _totalCents;
        public int AmountPaid => _amountPaid;
        public int ChangeDue => _changeDue;

        public event Action<State> OnStateChanged;

        public void StartTransaction()
        {
            if (_state != State.Idle) throw new InvalidOperationException("Transaction already active");
            _state = State.Scanning;
            _scannedItems.Clear();
            _totalCents = 0;
            _amountPaid = 0;
            _changeDue = 0;
            OnStateChanged?.Invoke(_state);
        }

        public void ScanProduct(ProductData product, int price)
        {
            if (_state != State.Scanning) throw new InvalidOperationException("Not in scanning state");
            _scannedItems.Add(product);
            _totalCents += price;
        }

        public void SubmitPayment(int amountCents)
        {
            if (_state != State.Scanning) throw new InvalidOperationException("Not in scanning state");
            _amountPaid = amountCents;
            int change = _amountPaid - _totalCents;
            _changeDue = change >= 0 ? change : 0;
            _state = State.Payment;
            OnStateChanged?.Invoke(_state);
        }

        public void CompleteTransaction()
        {
            if (_state != State.Payment) throw new InvalidOperationException("Not in payment state");
            _state = State.Complete;
            OnStateChanged?.Invoke(_state);
        }

        public void Reset()
        {
            _state = State.Idle;
            _scannedItems.Clear();
            _totalCents = 0;
            _amountPaid = 0;
            _changeDue = 0;
            OnStateChanged?.Invoke(_state);
        }
    }
}
