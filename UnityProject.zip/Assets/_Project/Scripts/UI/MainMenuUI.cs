using UnityEngine;
using UnityEngine.SceneManagement;
using ShelfLife.Systems;

namespace ShelfLife.UI
{
    public class MainMenuUI : MonoBehaviour
    {
        [SerializeField] private GameObject continueButton;
        [SerializeField] private SaveLoadService saveService;

        private void Start()
        {
            saveService = new SaveLoadService(Application.persistentDataPath);
            bool hasSave = saveService.SaveExists();
            continueButton.SetActive(hasSave);
        }

        public void NewGame()
        {
            saveService.DeleteSave();
            SceneManager.LoadScene("Shop");
        }

        public void ContinueGame()
        {
            if (saveService.SaveExists())
                SceneManager.LoadScene("Shop");
        }

        public void Quit() => Application.Quit();
    }
}
