using UnityEngine;
using UnityEngine.UI;
using ShelfLife.Gameplay;

namespace ShelfLife.UI
{
    public class HUDController : MonoBehaviour
    {
        [SerializeField] private Text cashText;
        [SerializeField] private Text dayText;
        [SerializeField] private DayCycleManager dayManager;

        private void Update()
        {
            // Update UI elements
        }
    }
}
