using UnityEngine;
using UnityEngine.UI;
using ShelfLife.Systems;
using ShelfLife.Data;
using ShelfLife.Gameplay;

namespace ShelfLife.UI
{
    public class CheckoutUI : MonoBehaviour
    {
        [SerializeField] private Text scannedItemsText;
        [SerializeField] private Text totalText;
        [SerializeField] private Text paymentText;
        [SerializeField] private Text changeText;
        [SerializeField] private Button[] numberButtons;
        [SerializeField] private Button clearButton;
        [SerializeField] private Button payButton;
        [SerializeField] private CheckoutStateMachine stateMachine;
        [SerializeField] private CheckoutCounterInteractor interactor;

        private int _currentPayment = 0;

        private void Start()
        {
            stateMachine.OnStateChanged += UpdateUI;
            for (int i = 0; i < numberButtons.Length; i++)
            {
                int digit = i;
                numberButtons[i].onClick.AddListener(() => AppendDigit(digit));
            }
            clearButton.onClick.AddListener(() => _currentPayment = 0);
            payButton.onClick.AddListener(() => { if (stateMachine.CurrentState == CheckoutStateMachine.State.Scanning) interactor.SubmitPayment(_currentPayment); });
        }

        private void AppendDigit(int digit)
        {
            _currentPayment = _currentPayment * 10 + digit;
            UpdateUI(stateMachine.CurrentState);
        }

        private void UpdateUI(CheckoutStateMachine.State state)
        {
            if (state == CheckoutStateMachine.State.Idle)
            {
                scannedItemsText.text = "Ready";
                totalText.text = "$0.00";
                paymentText.text = "$0.00";
                changeText.text = "$0.00";
                return;
            }
            scannedItemsText.text = stateMachine.ScannedItems.Count + " items";
            totalText.text = "$" + (stateMachine.TotalCents / 100f).ToString("0.00");
            paymentText.text = "$" + (_currentPayment / 100f).ToString("0.00");
            if (state == CheckoutStateMachine.State.Payment)
            {
                int change = stateMachine.ChangeDue;
                changeText.text = "Change: $" + (change / 100f).ToString("0.00");
            }
            else
                changeText.text = "";
        }
    }
}
