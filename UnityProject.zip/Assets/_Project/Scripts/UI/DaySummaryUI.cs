using UnityEngine;
using UnityEngine.UI;

namespace ShelfLife.UI
{
    public class DaySummaryUI : MonoBehaviour
    {
        [SerializeField] private Text revenueText;
        [SerializeField] private Text costsText;
        [SerializeField] private Text netText;
        [SerializeField] private Button continueButton;
        [SerializeField] private DayCycleManager dayManager;

        public void Show(int revenue, int costs, int net)
        {
            gameObject.SetActive(true);
            revenueText.text = "Revenue: $" + (revenue / 100f).ToString("0.00");
            costsText.text = "Costs: $" + (costs / 100f).ToString("0.00");
            netText.text = "Net: $" + (net / 100f).ToString("0.00");
            continueButton.onClick.AddListener(() => { gameObject.SetActive(false); dayManager.ContinueToNextDay(); });
        }
    }
}
