using UnityEngine;
using UnityEngine.UI;
using ShelfLife.Data;
using ShelfLife.Systems;

namespace ShelfLife.UI
{
    public class PricingPanelUI : MonoBehaviour
    {
        [SerializeField] private GameObject rowPrefab;
        [SerializeField] private Transform rowContainer;
        [SerializeField] private ProductData[] products;

        private void Start()
        {
            foreach (var product in products)
            {
                GameObject row = Instantiate(rowPrefab, rowContainer);
                var icon = row.transform.Find("Icon").GetComponent<Image>();
                icon.sprite = product.icon;
                var nameText = row.transform.Find("Name").GetComponent<Text>();
                nameText.text = product.displayName;
                var wholesaleText = row.transform.Find("Wholesale").GetComponent<Text>();
                wholesaleText.text = "$" + (product.wholesaleCost / 100f).ToString("0.00");
                var priceStepper = row.GetComponent<PriceStepper>();
                if (priceStepper != null)
                    priceStepper.Initialize(product, product.suggestedPrice);
            }
        }
    }

    public class PriceStepper : MonoBehaviour
    {
        public ProductData product;
        public int currentPrice;
        public Text priceText;
        public Button minusButton;
        public Button plusButton;
        public Text projectedText;

        public void Initialize(ProductData p, int initialPrice)
        {
            product = p;
            currentPrice = initialPrice;
            UpdateUI();
            minusButton.onClick.AddListener(() => { currentPrice = Mathf.Max(1, currentPrice - 5); UpdateUI(); });
            plusButton.onClick.AddListener(() => { currentPrice += 5; UpdateUI(); });
        }

        private void UpdateUI()
        {
            priceText.text = "$" + (currentPrice / 100f).ToString("0.00");
            float projected = PricingModel.ProjectedSellThrough(product, currentPrice, 100);
            projectedText.text = "Proj: " + projected.ToString("0.0") + "/day";
        }
    }
}
