using NUnit.Framework;
using ShelfLife.Systems;
using ShelfLife.Data;
using UnityEngine;

namespace ShelfLife.Tests
{
    public class PricingModelTests
    {
        private ProductData _product;

        [SetUp]
        public void Setup()
        {
            _product = ScriptableObject.CreateInstance<ProductData>();
            _product.wholesaleCost = 100;
            _product.suggestedPrice = 130;
        }

        [Test]
        public void ComputeSuggestedPrice_ReturnsMarkup()
        {
            int price = PricingModel.ComputeSuggestedPrice(_product, 1.0f);
            Assert.AreEqual(130, price);
        }

        [Test]
        public void ProjectedSellThrough_DecreasesWithPriceIncrease()
        {
            float lowPrice = PricingModel.ProjectedSellThrough(_product, 100, 100);
            float highPrice = PricingModel.ProjectedSellThrough(_product, 200, 100);
            Assert.Greater(lowPrice, highPrice);
        }
    }
}
