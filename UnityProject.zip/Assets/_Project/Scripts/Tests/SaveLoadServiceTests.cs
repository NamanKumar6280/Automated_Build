using NUnit.Framework;
using ShelfLife.Systems;
using ShelfLife.Data;
using System.IO;

namespace ShelfLife.Tests
{
    public class SaveLoadServiceTests
    {
        private string _testPath;
        private SaveLoadService _service;

        [SetUp]
        public void Setup()
        {
            _testPath = Path.Combine(Path.GetTempPath(), "test_save.json");
            _service = new SaveLoadService(Path.GetTempPath());
            if (File.Exists(_testPath)) File.Delete(_testPath);
        }

        [TearDown]
        public void Teardown()
        {
            if (File.Exists(_testPath)) File.Delete(_testPath);
        }

        [Test]
        public void Save_And_Load_RestoresState()
        {
            var data = new StoreStateData();
            data.dayNumber = 5;
            data.cashOnHand = 10000;
            data.stock["CannedBeans"] = 20;
            _service.Save(data);

            var loaded = _service.Load();
            Assert.NotNull(loaded);
            Assert.AreEqual(5, loaded.dayNumber);
            Assert.AreEqual(10000, loaded.cashOnHand);
            Assert.AreEqual(20, loaded.stock["CannedBeans"]);
        }

        [Test]
        public void SaveExists_ReturnsTrue_AfterSave()
        {
            Assert.IsFalse(_service.SaveExists());
            _service.Save(new StoreStateData());
            Assert.IsTrue(_service.SaveExists());
        }
    }
}
