using NUnit.Framework;
using ShelfLife.Systems;
using ShelfLife.Data;
using UnityEngine;

namespace ShelfLife.Tests
{
    public class InventorySystemTests
    {
        private InventorySystem _inventory;
        private ProductData _product;

        [SetUp]
        public void Setup()
        {
            _inventory = new InventorySystem();
            _product = ScriptableObject.CreateInstance<ProductData>();
            _product.name = "TestProduct";
        }

        [Test]
        public void AddStock_IncreasesCount()
        {
            _inventory.AddStock(_product, 10);
            Assert.AreEqual(10, _inventory.GetStock(_product));
        }

        [Test]
        public void RemoveStock_DecreasesCount_WhenSufficient()
        {
            _inventory.AddStock(_product, 10);
            bool success = _inventory.RemoveStock(_product, 5);
            Assert.IsTrue(success);
            Assert.AreEqual(5, _inventory.GetStock(_product));
        }

        [Test]
        public void RemoveStock_Fails_WhenInsufficient()
        {
            _inventory.AddStock(_product, 3);
            bool success = _inventory.RemoveStock(_product, 5);
            Assert.IsFalse(success);
            Assert.AreEqual(3, _inventory.GetStock(_product));
        }
    }
}
