using NUnit.Framework;
using ShelfLife.Systems;
using ShelfLife.Data;
using UnityEngine;

namespace ShelfLife.Tests
{
    public class CheckoutStateMachineTests
    {
        private CheckoutStateMachine _machine;
        private ProductData _product;

        [SetUp]
        public void Setup()
        {
            _machine = new CheckoutStateMachine();
            _product = ScriptableObject.CreateInstance<ProductData>();
            _product.name = "TestProduct";
            _product.wholesaleCost = 100;
            _product.suggestedPrice = 150;
        }

        [Test]
        public void StartTransaction_TransitionsToScanning()
        {
            _machine.StartTransaction();
            Assert.AreEqual(CheckoutStateMachine.State.Scanning, _machine.CurrentState);
        }

        [Test]
        public void ScanProduct_AddsItemAndTotal()
        {
            _machine.StartTransaction();
            _machine.ScanProduct(_product, 150);
            Assert.AreEqual(1, _machine.ScannedItems.Count);
            Assert.AreEqual(150, _machine.TotalCents);
        }

        [Test]
        public void SubmitPayment_WithOverpayment_GivesChange()
        {
            _machine.StartTransaction();
            _machine.ScanProduct(_product, 150);
            _machine.SubmitPayment(200);
            Assert.AreEqual(CheckoutStateMachine.State.Payment, _machine.CurrentState);
            Assert.AreEqual(50, _machine.ChangeDue);
        }

        [Test]
        public void CompleteTransaction_TransitionsToComplete()
        {
            _machine.StartTransaction();
            _machine.ScanProduct(_product, 150);
            _machine.SubmitPayment(150);
            _machine.CompleteTransaction();
            Assert.AreEqual(CheckoutStateMachine.State.Complete, _machine.CurrentState);
        }
    }
}
