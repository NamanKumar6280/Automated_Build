using System.Collections.Generic;

namespace ShelfLife.Data
{
    [System.Serializable]
    public class StoreStateData
    {
        public int schemaVersion = 1;
        public int dayNumber = 1;
        public int cashOnHand = 50000;
        public Dictionary<string, int> stock = new Dictionary<string, int>();
        public Dictionary<string, int> prices = new Dictionary<string, int>();
    }
}
