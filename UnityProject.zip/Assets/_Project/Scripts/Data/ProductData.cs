using UnityEngine;

namespace ShelfLife.Data
{
    [CreateAssetMenu(fileName = "Product_", menuName = "Shelf Life/Product Data")]
    public class ProductData : ScriptableObject
    {
        public string displayName;
        public Sprite icon;
        public ProductCategory category;
        public int wholesaleCost;
        public int suggestedPrice;
        public int shelfStackSize;
    }

    public enum ProductCategory
    {
        PackagedGoods,
        Produce,
    }
}
