using UnityEngine;

namespace ShelfLife.Data
{
    [CreateAssetMenu(fileName = "CustomerProfile_", menuName = "Shelf Life/Customer Profile")]
    public class CustomerProfileData : ScriptableObject
    {
        public float patience = 30f;
        public float budgetSensitivity = 0.5f;
        public float listAdherence = 0.7f;
        public float minBrowseTime = 5f;
        public float maxBrowseTime = 15f;
        public int minItems = 1;
        public int maxItems = 4;
    }
}
