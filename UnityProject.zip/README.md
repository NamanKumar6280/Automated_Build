# Shelf Life – M1 Automated Build

This project is fully headless-ready. All editor steps are automated.

## Run Setup
- In Unity Editor: Tools/Project/Complete Setup
- In headless mode: -executeMethod ShelfLife.Editor.Setup.SetupRunner.Run

## Build
The project will build Android APK with IL2CPP, ARM64, API 26.

## CI
The included .github/workflows/build.yml sets up GitHub Actions to:
- Install Unity 6000.0.35f1
- Run SetupRunner
- Build APK
- Upload artifact
