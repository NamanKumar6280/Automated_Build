using System;
using System.IO;
using System.Text.Json;
using ShelfLife.Data;

namespace ShelfLife.Systems
{
    public class SaveLoadService
    {
        private readonly string _savePath;
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions { WriteIndented = true };

        public SaveLoadService(string persistentDataPath)
        {
            _savePath = Path.Combine(persistentDataPath, "save.json");
        }

        public bool SaveExists() => File.Exists(_savePath);

        public void Save(StoreStateData data)
        {
            data.schemaVersion = 1;
            string json = JsonSerializer.Serialize(data, _options);
            File.WriteAllText(_savePath, json);
        }

        public StoreStateData Load()
        {
            if (!SaveExists()) return null;
            string json = File.ReadAllText(_savePath);
            using JsonDocument doc = JsonDocument.Parse(json);
            int version = doc.RootElement.GetProperty("schemaVersion").GetInt32();
            if (version == 1)
                return JsonSerializer.Deserialize<StoreStateData>(json);
            else
                throw new NotSupportedException($"Schema version {version} not supported.");
        }

        public void DeleteSave()
        {
            if (SaveExists()) File.Delete(_savePath);
        }
    }
}
