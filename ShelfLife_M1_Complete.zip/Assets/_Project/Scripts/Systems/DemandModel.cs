using System;
using UnityEngine;

namespace ShelfLife.Systems
{
    public class DemandModel
    {
        private Random _rng;
        private float _currentFluctuation = 1.0f;

        public DemandModel(int seed)
        {
            _rng = new Random(seed);
        }

        public float GetWholesalePriceMultiplier()
        {
            float step = (float)(_rng.NextDouble() * 0.06 - 0.03);
            _currentFluctuation += step;
            _currentFluctuation = Math.Clamp(_currentFluctuation, 0.8f, 1.2f);
            return _currentFluctuation;
        }

        public void ResetTo(float value) => _currentFluctuation = value;
    }
}
